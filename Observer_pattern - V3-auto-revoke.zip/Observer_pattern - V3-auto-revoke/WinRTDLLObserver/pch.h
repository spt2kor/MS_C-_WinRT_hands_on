﻿#pragma once
#include <windows.h>
#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.Foundation.Collections.h>



#include <iostream>
#include <memory>
#include <mutex>
using namespace std;


