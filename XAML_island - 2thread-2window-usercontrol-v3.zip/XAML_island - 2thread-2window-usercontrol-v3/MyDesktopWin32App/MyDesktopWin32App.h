#pragma once

#include "resource.h"
#include "windows.h"
